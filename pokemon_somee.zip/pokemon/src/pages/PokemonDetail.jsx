function PokemonDetail() {
    return (
        <>디테일페이지</>
    )
}

export default PokemonDetail